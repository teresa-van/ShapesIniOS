var searchData=
[
  ['vehicle',['Vehicle',['../classOnlineMapsGoogleDirectionsResult_1_1Vehicle.html',1,'OnlineMapsGoogleDirectionsResult']]],
  ['vehicletype',['VehicleType',['../classOnlineMapsHereRoutingAPI_1_1VehicleType.html',1,'OnlineMapsHereRoutingAPI']]]
];
